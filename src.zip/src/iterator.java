import java.util.ArrayList;

public class iterator {

	public static void main(String[] args) {
		ArrayList<String> strlist=new ArrayList<String>();
		strlist.add("yukta");
		strlist.add("samira");
		strlist.add("sakshi");
		strlist.add("reshma");
		strlist.add("aarti");
		
		System.out.println(strlist);
		for (String s:strlist) {
			System.out.println(s+" ");
			
		}
		
		//Iterator<String>it=strlist
		

	}

}

import java.util.ArrayList;

import java.util.Collections;

public class Arraylist {

	public static void main(String[] args) {
		ArrayList<Integer>list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		list.add(60);
		
		System.out.println("list before removal"+list);
		list.remove(2);
		System.out.println("list after removal"+list);
		Collections.sort(list);
		System.out.println("sorted list"+list);
		
		int sum=0;
		for (int num:list) {
			sum+=num;
		
		}
		System.out.println("sum of all elements is"+sum);
		
		

	}

}



























class Person {
	String Name;

	public Person(String name) {
		super();
		Name=name;
		
	}
	
}
class Student extends Person{
	int Rollno;

	public Student(String name, int rollno) {
		super(name);
		Rollno = rollno;
	}
	
}
class EngineerStudent extends Student{
	String branch;

	public EngineerStudent(String name, int rollno, String branch) {
		super(name, rollno);
		this.branch = branch;
	}
	
}
public class ConstructorChaining{
	public static void main(String[]args) {
		EngineerStudent enst=new EngineerStudent ("yukta", 103, "DBDA");
		System.out.println("the name is :"+enst.Name);
		System.out.println("the Rollno is :"+enst.Rollno);
		System.out.println("the branch is :"+enst.branch);
		
		
		
	}
}
	
import java.util.ArrayList;

class Animal {
		public void makesound() {
			System.out.println("Animal makes sound");
		}
	}
class Dog extends Animal{
		@Override
		public void makesound() {
			System.out.println("woof woof");
		}
	}
class Cat extends Animal{
		@Override
		public void makesound() {
			System.out.println("meow meow");
		}
	}
class Cow extends Animal{
		@Override
		public void makesound() {
			System.out.println("moo moo");
		}
	}
public class AnimalSound{
	public static void main(String[] args) {
			ArrayList<Animal>animals=new ArrayList<Animal>();
			animals.add(new Animal());
			animals.add(new Dog());
			animals.add(new Cat());
			animals.add(new Cow());
			
			
			for(Animal animal:animals)
			{
				animal.makesound();
			}

		}

	

}


		

class vechicle {
	void move() {
		System.out.println("car is moving");
	}
	
	class car extends vechicle{
		void main() {
			System.out.println("car is driving on road");
		}
	}
	class bike extends vechicle{
		void main() {
			System.out.println("bike is driving o road");
		}
	}
	


public static void main(String[] args) {
	vechicle Vechicle1= new car();
	vechicle Vechicle2= new bike();
		
	Vechicle1.move();
	Vechicle2.move();
		
		
	}

}
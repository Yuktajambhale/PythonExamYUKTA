import java.util.LinkedList;

class LinkedListOperation {

	public static void main(String[] args) {
		LinkedList<String>cities=new LinkedList<String>();
		
		cities.add("mumbai");
		cities.add("thane");
		cities.add("pune");
		cities.add("badlapur");
		cities.add("mulund");
		System.out.println("all cities before adding:"+cities);
		
		cities.addFirst("berlin");
		System.out.println("all cities after adding:"+cities);
		
		cities.addLast("kopri");
		System.out.println("last citie added:"+cities);
		
		cities.remove(2);
		System.out.println("city removed:"+cities);
		
		for(String city:cities) {
			System.out.println(city);
		}
		
		
		
		
		

	}

}

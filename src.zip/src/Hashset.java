import java.util.HashSet;

public class Hashset {

	public static void main(String[] args) {
		 HashSet<Integer>set=new HashSet<Integer>();
		 set.add(1);
		 set.add(2);
		 set.add(3);
		 set.add(4);
		 set.add(5);
		 
		 
		 System.out.println("hashset elements are"+ set);

 
		


	}

}

























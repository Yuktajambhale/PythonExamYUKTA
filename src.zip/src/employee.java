import java.util.MissingFormatArgumentException;

public class employee {
	
	int empId;
	String name;
	double salary;
	

	public employee() {
		super();
	}
	


	public employee(int empId, String name, double salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
	}
	
	public void Incrementsalary(double amount) {
		try {
			if (amount<0) {
				throw new MissingFormatArgumentException("sallary argument cannot be negative");	
			}
			salary+=amount;
			System.out.println("salary incremented successfully");
		}catch(MissingFormatArgumentException e) {
			System.out.println("error" +e.getMessage());
		}
		
	}


	public void display() {
		System.out.println("Employee id"+empId);
		System.out.println("Employee name"+name);
		System.out.println("Employee salary"+salary);
		
		
	
	}



	public static void main(String[] args) {
		
		   
        employee emp = new employee(101, "John Doe", 50000.00);

        
        emp.display();

        
        emp.Incrementsalary(5000.00);
        emp.display();

        
        emp.Incrementsalary(-1000.00);
		

	}

}




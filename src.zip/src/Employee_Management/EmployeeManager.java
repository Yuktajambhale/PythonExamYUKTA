package Employee_Management;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class EmployeeManager {
    private List<Employee> employees;

   
    public EmployeeManager() {
        employees = new ArrayList<>();
    }

    
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    
    public boolean removeEmployee(String employeeId) {
        return employees.removeIf(employee -> employee.getEmployeeId().equals(employeeId));
    }

    
    public double calculateTotalSalaryByDepartment(String department) {
        double totalSalary = 0.0;
        for (Employee employee : employees) {
            if (employee.getDepartment().equalsIgnoreCase(department)) {
                totalSalary += employee.getSalary();
            }
        }
        return totalSalary;
    }

    
    public Map<String, Employee> findHighestSalaryInEachDepartment() {
        Map<String, Employee> highestSalaryEmployees = new HashMap<>();
        for (Employee employee : employees) {
            String department = employee.getDepartment();
            if (!highestSalaryEmployees.containsKey(department) || 
                employee.getSalary() > highestSalaryEmployees.get(department).getSalary()) {
                highestSalaryEmployees.put(department, employee);
            }
        }
        return highestSalaryEmployees;
    }

    
    public void displayEmployees() {
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}

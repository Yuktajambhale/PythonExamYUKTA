package Employee_Management;

import java.util.Map;

public class Main {
    public static void main(String[] args) {
        
        EmployeeManager employeeManager = new EmployeeManager();

        
        Employee emp1 = new Employee("E001", "Alice", "HR", 60000.00);
        Employee emp2 = new Employee("E002", "Bob", "Engineering", 90000.00);
        Employee emp3 = new Employee("E003", "Charlie", "HR", 65000.00);
        Employee emp4 = new Employee("E004", "David", "Engineering", 95000.00);
        Employee emp5 = new Employee("E005", "Eve", "Marketing", 70000.00);

        
        employeeManager.addEmployee(emp1);
        employeeManager.addEmployee(emp2);
        employeeManager.addEmployee(emp3);
        employeeManager.addEmployee(emp4);
        employeeManager.addEmployee(emp5);

        
        System.out.println("All Employees:");
        employeeManager.displayEmployees();

        
        System.out.println("\nTotal Salary for Engineering Department: $" + employeeManager.calculateTotalSalaryByDepartment("Engineering"));

        
        System.out.println("\nHighest Paid Employee in Each Department:");
        Map<String, Employee> highestSalaries = employeeManager.findHighestSalaryInEachDepartment();
        for (Map.Entry<String, Employee> entry : highestSalaries.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

       
        System.out.println("\nRemoving Employee E002 (Bob)");
        employeeManager.removeEmployee("E002");

        
        System.out.println("\nAll Employees After Removal:");
        employeeManager.displayEmployees();
    }
}

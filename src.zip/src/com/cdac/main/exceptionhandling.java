package com.cdac.main;

public class exceptionhandling {

	public static void main(String[] args) {
		int num1=3;
		int num2=0;
		int res=num1/num2;
		try {
			res=num1/num2;
		}
		catch(ArithmeticException ex)
		{
			System.out.println("Catch:"+getMessage());
		}
		System.out.println("the res:"+ex.getmessage());
		
	}

}

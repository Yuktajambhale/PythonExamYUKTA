package com.cdac.main;

import java.util.Scanner;

public class cutomexception {
	

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in)
		int num1=0;
		System.out.println("enter the number")
		try
		{
			num1=scan.nextInt();
		}
		catch(inputMismatchException ex)
		{
			System.out.println("kindly enter only digits not greater than ");
			System.out.println("enter number again");
			try {
				Scanner sc=new Scanner(System.in)
			}
		}
				
		

	}

}

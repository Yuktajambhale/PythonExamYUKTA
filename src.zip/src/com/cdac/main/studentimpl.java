package com.cdac.impl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cdac.Exceptions.NegetiveAgeException;
import com.cdac.dao.IStudentManager;
import com.cdac.model.Student;

public class StudentManager implements IStudentManager
{
	
	ArrayList<Student> slist=new ArrayList<Student>();
	
	public StudentManager()
	{
		slist.add(new Student(101, "Malkeet", 34, 53636.89f));
		slist.add(new Student(102, "Sahil", 24, 7347.89f));
	}
	
	public void AddStudent() throws NegetiveAgeException
	{
		Scanner sc=new Scanner(System.in);
		Student s=new Student();
		System.out.println("Enter Roll No");
		s.RollNo=sc.nextInt();
		System.out.println("Enter Name");
		s.Name=sc.next();
		System.out.println("Enter Age");
		s.Age=sc.nextInt();
		
		if(s.Age<0)
		{
			throw new NegetiveAgeException("Age must be greater than 0");
		}
		System.out.println("Enter Fees");
		s.Fees=sc.nextFloat();
		
		slist.add(s);
		System.err.println("Student Added Successfully");
	}
	
	public void PrintAllStudents()
	{
		for(Student s:slist)
		{
			System.out.println(s);
		}
	}
	
	public void UpdateStudent()
	{
		Scanner su=new Scanner(System.in);
		System.out.println("Enter Roll No of Student to be Upadted");
		int rn=su.nextInt();
		boolean flag=false;
		for(Student s:slist)
		{
			if(rn==s.RollNo)
			{
package com.cdac.main;

public class student;
{
	public int rollno;
	public String name;
	public int age
	public float fees;
	
	public student() {
		super();
	}

	public student(int rollno, String name, int age, float fees) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.age = age;
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "rollno=" + rollno + ", name=" + name + ", age=" + age + ", fees=" + fees";
	}

	
	
}
























	
	
}

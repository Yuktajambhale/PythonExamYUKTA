package com.cdac.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.cdac.Exceptions.NegetiveAgeException;
import com.cdac.impl.StudentManager;


public class CollectionsOfUserDefined {
	
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		
		StudentManager sm=new StudentManager();
		
		int choice=0;
		
		do
		{
			System.out.println("=====================Student Management======================");
			System.out.println("Press 1 to Add Student");
			System.out.println("Press 2 to View All Student");
			System.out.println("Press 3 to Update Student");
			System.out.println("Press 4 to Delete Student");
			System.out.println("Press 5 to Exit");
			System.out.println("=====================Student Management======================");
			System.out.println("Please Enter Your Choice");
			choice=scan.nextInt();
			
			switch (choice) {
			case 1:
			{
				try
				{
					sm.AddStudent();
				}
				catch(NegetiveAgeException ex)
				{
					System.out.println("Exception: "+ex.getMessage());
					System.out.println("Please Start adding of Student again");
				}
				break;
			}
			case 2:
			{
				sm.PrintAllStudents();
				break;
			}
			case 3:
			{
				sm.UpdateStudent();
				break;
			}
			case 4:
			{
				sm.DeleteStudent();
				break;
			}
			case 5:
			{
				System.out.println("Exiting Program");
				break;
			}
			default:
				System.out.println("Invalid Choice");
				break;
			}
		}while(choice!=5);
		
	}
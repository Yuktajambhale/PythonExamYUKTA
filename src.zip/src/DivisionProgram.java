import java.util.Scanner;
import java.util.InputMismatchException;

public class DivisionProgram {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Taking two integer inputs from the user
            System.out.print("Enter the first integer (numerator): ");
            int num1 = scanner.nextInt();
            System.out.print("Enter the second integer (denominator): ");
            int num2 = scanner.nextInt();

            // Performing the division
            int result = num1 / num2;
            System.out.println("The result of division is: " + result);

        } catch (ArithmeticException e) {
            // Handling division by zero
            System.out.println("Error: Cannot divide by zero.");

        } catch (InputMismatchException e) {
            // Handling invalid input
            System.out.println("Error: Invalid input. Please enter integers only.");

        } finally {
            // This block will always execute
            System.out.println("End of program.");
        }

        // Closing the scanner
        scanner.close();
    }
}

